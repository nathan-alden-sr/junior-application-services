﻿using System.Reflection;

[assembly:AssemblyTitle("Junior.ApplicationServices.UnitTests")]